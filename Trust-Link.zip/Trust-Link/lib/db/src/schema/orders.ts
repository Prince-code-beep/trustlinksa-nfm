import { createInsertSchema } from "drizzle-zod";
import { integer, numeric, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const ordersTable = pgTable("trustlink_orders", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").notNull(),
  listingTitle: text("listing_title").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  status: text("status").notNull().default("in_escrow"),
  deliveryAddress: text("delivery_address").notNull(),
  deliveryStatus: text("delivery_status").notNull().default("pending"),
  sellerName: text("seller_name").notNull(),
  protectionEndsAt: timestamp("protection_ends_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  disputeReason: text("dispute_reason"),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  id: true,
  createdAt: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;