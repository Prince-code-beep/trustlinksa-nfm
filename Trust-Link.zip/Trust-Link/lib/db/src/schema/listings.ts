import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, numeric, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const listingsTable = pgTable("trustlink_listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull(),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull(),
  location: text("location").notNull(),
  distanceKm: numeric("distance_km", { precision: 6, scale: 2 }).notNull(),
  sellerName: text("seller_name").notNull(),
  sellerInitials: text("seller_initials").notNull(),
  sellerRating: numeric("seller_rating", { precision: 3, scale: 2 }).notNull(),
  sellerSales: integer("seller_sales").notNull().default(0),
  isVerified: boolean("is_verified").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  status: text("status").notNull().default("available"),
});

export const insertListingSchema = createInsertSchema(listingsTable).omit({
  id: true,
  distanceKm: true,
  sellerName: true,
  sellerInitials: true,
  sellerRating: true,
  sellerSales: true,
  isVerified: true,
  createdAt: true,
  status: true,
});

export type InsertListing = z.infer<typeof insertListingSchema>;
export type Listing = typeof listingsTable.$inferSelect;