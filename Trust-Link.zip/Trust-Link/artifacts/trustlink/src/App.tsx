import { useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bookmark,
  Check,
  ChevronDown,
  CircleAlert,
  Compass,
  FileCheck2,
  HeartHandshake,
  ImagePlus,
  LockKeyhole,
  MapPin,
  Menu,
  MessageCircle,
  PackageCheck,
  PencilLine,
  Plus,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Star,
  Tag,
  UserRound,
  WalletCards,
  X,
} from 'lucide-react';
import {
  getGetDashboardQueryKey,
  getGetListingQueryKey,
  getGetProfileQueryKey,
  getListListingsQueryKey,
  getListOrdersQueryKey,
  useConfirmOrder,
  useCreateListing,
  useCreateOrder,
  useDisputeOrder,
  useGetDashboard,
  useGetListing,
  useGetProfile,
  useListListings,
  useListOrders,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Switch, useLocation, useParams } from 'wouter';

const queryClient = new QueryClient();

type ListingLike = {
  id: number; title: string; description: string; price: number; imageUrl: string;
  category: string; location: string; distanceKm: number; sellerName: string;
  sellerInitials: string; sellerRating: number; sellerSales: number; isVerified: boolean;
  createdAt: string; status: string;
};
type OrderLike = {
  id: number; listingId: number; listingTitle: string; amount: number; status: string;
  deliveryAddress: string; deliveryStatus: string; sellerName: string; protectionEndsAt: string; createdAt: string;
  disputeReason?: string | null;
};

const categories = ['All nearby', 'Home finds', 'Tech', 'Fashion', 'Outdoors', 'Collectibles'];
const currency = (value: number) => `R${value.toLocaleString('en-ZA')}`;
const shortDate = (value?: string) => value ? new Date(value).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' }) : 'Today';
const fallbackImage = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 700"%3E%3Cdefs%3E%3ClinearGradient id="g" x1="0" y1="0" x2="1" y2="1"%3E%3Cstop stop-color="%23c8ded3"/%3E%3Cstop offset="1" stop-color="%23f0cd80"/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width="900" height="700" fill="url(%23g)"/%3E%3Ccircle cx="690" cy="150" r="110" fill="%23f9f4e9" fill-opacity=".35"/%3E%3C/svg%3E';
const statusLabel: Record<string, string> = {
  payment_pending: 'Payment pending', in_escrow: 'Protected in escrow', delivery_in_transit: 'Dispatch in transit',
  delivered: 'Delivered · ready to check',
  completed: 'Completed', disputed: 'Under review', cancelled: 'Cancelled',
};
const deliveryLabel: Record<string, string> = {
  pending: 'Dispatch pending',
  in_transit: 'In transit',
  delivered: 'Delivered',
};

function Logo() {
  return <Link href="/" className="flex items-center gap-2.5" data-testid="link-logo">
    <span className="grid size-9 place-items-center rounded-[12px] bg-[#f2c45a] text-[#183b3e] shadow-sm">
      <ShieldCheck size={20} strokeWidth={2.5} />
    </span>
    <span className="text-[19px] font-extrabold tracking-[-.04em] text-[#183b3e]">trust<span className="text-[#df6c55]">link</span></span>
  </Link>;
}

function Avatar({ initials, size = 'md' }: { initials?: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'size-8 text-[10px]', md: 'size-10 text-xs', lg: 'size-20 text-xl' };
  return <span className={`grid shrink-0 place-items-center rounded-full bg-[#d9e8df] font-bold text-[#27635f] ${sizes[size]}`} data-testid="img-avatar">
    {initials || 'TL'}
  </span>;
}

function TrustPill({ children, warm = false }: { children: React.ReactNode; warm?: boolean }) {
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold ${warm ? 'bg-[#fff0c6] text-[#805f11]' : 'bg-[#dcefe9] text-[#27635f]'}`}>{children}</span>;
}

function ListingImage({ listing, className = '' }: { listing: ListingLike; className?: string }) {
  return <div className={`relative overflow-hidden bg-[#cbded5] ${className}`}>
    {listing.imageUrl ? <img src={listing.imageUrl} alt={listing.title} className="size-full object-cover transition-transform duration-500 group-hover:scale-[1.04]" data-testid={`img-listing-${listing.id}`} /> : (
      <div className="grid size-full place-items-center bg-[linear-gradient(135deg,#c8ded3,#f0cd80)]">
        <Tag className="text-[#27635f]/55" size={30} />
      </div>
    )}
    <span className="absolute left-3 top-3 rounded-full bg-[#f9f4e9]/90 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.12em] text-[#183b3e]">{listing.category}</span>
    {listing.isVerified && <span className="absolute right-3 top-3 grid size-7 place-items-center rounded-full bg-[#f9f4e9]/90 text-[#27736c]" title="Verified seller"><BadgeCheck size={16} /></span>}
  </div>;
}

function SkeletonCard() {
  return <div className="overflow-hidden rounded-[22px] border border-[#e4dcca] bg-[#f9f4e9]">
    <div className="h-48 animate-pulse-soft bg-[#e4dcca]" /><div className="space-y-3 p-4"><div className="h-3 w-2/3 animate-pulse-soft rounded-full bg-[#e4dcca]" /><div className="h-5 w-1/2 animate-pulse-soft rounded-full bg-[#e4dcca]" /></div>
  </div>;
}

function EmptyState({ title, detail, action }: { title: string; detail: string; action?: React.ReactNode }) {
  return <div className="rounded-[26px] border border-dashed border-[#c8d8ce] bg-[#edf4ef] px-6 py-12 text-center">
    <span className="mx-auto mb-4 grid size-12 place-items-center rounded-2xl bg-[#d7e9df] text-[#27635f]"><Compass size={23} /></span>
    <h3 className="font-display text-2xl text-[#183b3e]">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-[#607473]">{detail}</p>{action && <div className="mt-5">{action}</div>}
  </div>;
}

function ErrorState({ retry }: { retry?: () => void }) {
  return <div className="rounded-[26px] border border-[#eccbc0] bg-[#fff0ea] px-6 py-10 text-center">
    <CircleAlert className="mx-auto mb-3 text-[#c35c4d]" size={25} /><h3 className="font-display text-2xl text-[#733d34]">That didn’t load</h3>
    <p className="mt-2 text-sm text-[#8f625a]">We hit a small bump. Your saved details are still safe.</p>
    {retry && <button onClick={retry} className="mt-5 rounded-full bg-[#df6c55] px-5 py-2.5 text-sm font-bold text-[#fff9ee]" data-testid="button-retry">Try again</button>}
  </div>;
}

function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const nav = [
    { href: '/', label: 'Discover', icon: Compass },
    { href: '/orders', label: 'My deals', icon: ShoppingBag },
    { href: '/profile', label: 'Profile', icon: UserRound },
  ];
  return <div className="noise min-h-[100dvh] bg-[#f4efdf]">
    <header className="sticky top-0 z-40 border-b border-[#e3d9c7]/80 bg-[#f4efdf]/90 backdrop-blur-xl">
      <div className="mx-auto flex h-[70px] max-w-6xl items-center justify-between px-5 sm:px-8">
        <Logo />
        <nav className="hidden items-center gap-7 md:flex">
          {nav.map(({ href, label }) => <Link key={href} href={href} className={`text-sm font-bold transition-colors ${location === href ? 'text-[#df6c55]' : 'text-[#57706d] hover:text-[#183b3e]'}`} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`}>{label}</Link>)}
          <Link href="/safety" className="flex items-center gap-1.5 text-sm font-bold text-[#57706d] hover:text-[#183b3e]" data-testid="link-nav-safety"><LockKeyhole size={15} /> Safety</Link>
          <Link href="/sell" className="ml-1 inline-flex items-center gap-2 rounded-full bg-[#df6c55] px-4 py-2.5 text-sm font-bold text-[#fff9ee] shadow-sm transition-transform hover:-translate-y-0.5" data-testid="link-nav-sell"><Plus size={16} /> Sell something</Link>
        </nav>
        <div className="flex items-center gap-2 md:hidden"><Link href="/sell" className="grid size-10 place-items-center rounded-full bg-[#df6c55] text-[#fff9ee]" data-testid="link-mobile-sell"><Plus size={19} /></Link><button className="grid size-10 place-items-center rounded-full bg-[#e8e0ce] text-[#183b3e]" data-testid="button-mobile-menu"><Menu size={19} /></button></div>
      </div>
    </header>
    <main className="mx-auto max-w-6xl px-5 pb-28 pt-7 sm:px-8 md:pb-12">{children}</main>
    <nav className="safe-area-bottom fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around border-t border-[#dfd5c3] bg-[#f9f4e9]/95 px-5 pt-2 backdrop-blur-xl md:hidden">
      {nav.map(({ href, label, icon: Icon }) => <Link href={href} key={href} className={`flex min-w-[76px] flex-col items-center gap-1 py-1 text-[10px] font-bold ${location === href ? 'text-[#df6c55]' : 'text-[#778784]'}`} data-testid={`link-bottom-${label.toLowerCase().replace(' ', '-')}`}><Icon size={19} strokeWidth={location === href ? 2.5 : 2} /><span>{label}</span></Link>)}
      <Link href="/safety" className={`flex min-w-[76px] flex-col items-center gap-1 py-1 text-[10px] font-bold ${location === '/safety' ? 'text-[#df6c55]' : 'text-[#778784]'}`} data-testid="link-bottom-safety"><LockKeyhole size={19} /><span>Safety</span></Link>
    </nav>
  </div>;
}

function Home() {
  const [category, setCategory] = useState('All nearby');
  const [search, setSearch] = useState('');
  const params = useMemo(() => ({ limit: 30, ...(category !== 'All nearby' ? { category } : {}), ...(search ? { search } : {}) }), [category, search]);
  const listingsQuery = useListListings(params, { query: { queryKey: getListListingsQueryKey(params) } });
  const dashboardQuery = useGetDashboard({ query: { queryKey: getGetDashboardQueryKey() } });
  const listings = (listingsQuery.data || []) as ListingLike[];
  const featured = ((dashboardQuery.data?.featuredListings || listings.slice(0, 3)) as ListingLike[]);
  return <div className="space-y-10">
    <section className="relative overflow-hidden rounded-[30px] bg-[#183b3e] px-6 py-9 text-[#f9f4e9] sm:px-10 sm:py-12">
      <div className="absolute -right-12 -top-16 size-56 rounded-full border-[22px] border-[#2d6862]/50" /><div className="absolute -bottom-20 right-20 size-44 rounded-full border-[15px] border-[#df6c55]/25" />
      <div className="relative max-w-xl animate-rise-in"><div className="mb-5 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.18em] text-[#f2c45a]"><MapPin size={14} /> Cape Town, South Africa <ChevronDown size={14} /></div>
        <h1 className="font-display text-[clamp(3.25rem,10vw,6.25rem)] leading-[.86] tracking-[-.04em]">Good finds.<br /><em className="text-[#f2c45a]">Good people.</em></h1>
        <p className="mt-6 max-w-md text-[15px] leading-7 text-[#bed2c9]">A local marketplace where your money stays protected until you’re happy with what you bought.</p>
      </div>
      <div className="relative mt-8 flex max-w-lg items-center rounded-2xl bg-[#f9f4e9] p-1.5 text-[#183b3e] shadow-lg"><Search className="ml-3 text-[#7b918a]" size={19} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Try “camping gear” or “desk”" className="min-w-0 flex-1 bg-transparent px-3 py-3 text-sm outline-none placeholder:text-[#94a49e]" data-testid="input-search-listings" /><button className="hidden rounded-xl bg-[#f2c45a] px-4 py-3 text-xs font-extrabold sm:block" onClick={() => setSearch(search.trim())} data-testid="button-search-listings">Search</button></div>
    </section>
    <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {[
        { value: dashboardQuery.data?.nearbyCount ?? '—', label: 'nearby listings', icon: MapPin },
        { value: dashboardQuery.data?.safeDealsCount ?? '—', label: 'safe deals made', icon: ShieldCheck },
        { value: dashboardQuery.data?.averageDistanceKm ? `${dashboardQuery.data.averageDistanceKm} km` : '—', label: 'average distance', icon: Compass },
        { value: dashboardQuery.data?.trustScore ? `${dashboardQuery.data.trustScore}/100` : '—', label: 'community trust', icon: HeartHandshake },
      ].map(({ value, label, icon: Icon }, index) => <div className={`animate-rise-in delay-${index + 1} rounded-2xl border border-[#e3d9c7] bg-[#f9f4e9] p-4`} key={label}><Icon size={18} className="mb-5 text-[#df6c55]" /><p className="font-display text-3xl text-[#183b3e]" data-testid={`text-metric-${index}`}>{value}</p><p className="mt-1 text-[11px] font-bold uppercase tracking-[.1em] text-[#7c8c86]">{label}</p></div>)}
    </section>
    <section>
      <div className="mb-5 flex items-end justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-[#df6c55]">The local edit</p><h2 className="mt-1 font-display text-4xl tracking-[-.02em] text-[#183b3e]">Worth the doorstep drop.</h2></div><Link href="/" className="hidden text-sm font-bold text-[#27635f] sm:block" data-testid="link-see-all">See all nearby <ArrowRight className="ml-1 inline" size={15} /></Link></div>
      {dashboardQuery.isLoading ? <div className="grid gap-4 sm:grid-cols-3"><SkeletonCard /><SkeletonCard /><SkeletonCard /></div> : featured.length ? <div className="grid gap-4 sm:grid-cols-3">{featured.map((item, index) => <ListingCard key={item.id} listing={item} featured={index === 0} />)}</div> : <EmptyState title="Nothing close by yet" detail="Be the first good find in your neighbourhood." action={<Link href="/sell" className="rounded-full bg-[#df6c55] px-5 py-3 text-sm font-bold text-[#fff9ee]" data-testid="link-empty-sell">List something</Link>} />}
    </section>
    <section className="rounded-[26px] border border-[#d4e3d8] bg-[#e8f2eb] p-6 sm:flex sm:items-center sm:justify-between sm:p-8"><div className="flex gap-4"><span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-[#f2c45a] text-[#183b3e]"><LockKeyhole size={21} /></span><div><p className="text-sm font-extrabold text-[#183b3e]">Your money doesn’t go straight to a stranger.</p><p className="mt-1 max-w-lg text-sm leading-6 text-[#607473]">TrustLink holds payment in escrow until you confirm the item is as described. No awkward chasing.</p></div></div><Link href="/safety" className="mt-5 inline-flex items-center gap-2 text-sm font-extrabold text-[#27635f] sm:mt-0" data-testid="link-home-safety">How protection works <ArrowRight size={16} /></Link></section>
    <section><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-[#df6c55]">Browse nearby</p><h2 className="mt-1 font-display text-4xl text-[#183b3e]">Find your next one.</h2></div><span className="text-xs font-bold text-[#7c8c86]" data-testid="text-listing-count">{listings.length} results</span></div>
      <div className="mb-5 flex gap-2 overflow-x-auto pb-1">{categories.map(item => <button key={item} onClick={() => setCategory(item)} className={`whitespace-nowrap rounded-full px-4 py-2.5 text-xs font-bold transition-colors ${category === item ? 'bg-[#183b3e] text-[#f9f4e9]' : 'bg-[#e8e0ce] text-[#607473] hover:bg-[#dfd5c3]'}`} data-testid={`button-category-${item.toLowerCase().replace(' ', '-')}`}>{item}</button>)}</div>
      {listingsQuery.isLoading ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"><SkeletonCard /><SkeletonCard /><SkeletonCard /></div> : listingsQuery.isError ? <ErrorState retry={() => listingsQuery.refetch()} /> : listings.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{listings.map(item => <ListingCard key={item.id} listing={item} />)}</div> : <EmptyState title="The shelves are quiet" detail="Try a wider search, or put something lovely into the neighbourhood." action={<Link href="/sell" className="rounded-full bg-[#183b3e] px-5 py-3 text-sm font-bold text-[#f9f4e9]" data-testid="link-browse-empty-sell">Sell an item</Link>} />}
    </section>
  </div>;
}

function ListingCard({ listing, featured = false }: { listing: ListingLike; featured?: boolean }) {
  const [saved, setSaved] = useState(false);
  return <Link href={`/listing/${listing.id}`} className={`group block overflow-hidden rounded-[22px] border border-[#e3d9c7] bg-[#f9f4e9] shadow-[0_2px_10px_hsl(198_35%_17%/.04)] transition-all hover:-translate-y-1 hover:shadow-[0_16px_30px_hsl(198_35%_17%/.1)] ${featured ? 'sm:col-span-2 sm:grid sm:grid-cols-[1.15fr_1fr]' : ''}`} data-testid={`card-listing-${listing.id}`}>
    <ListingImage listing={listing} className={featured ? 'h-56 sm:h-full' : 'h-48'} /><div className="relative p-4 sm:p-5"><button onClick={(e) => { e.preventDefault(); setSaved(!saved); }} className={`absolute right-4 top-4 grid size-9 place-items-center rounded-full ${saved ? 'bg-[#df6c55] text-[#fff9ee]' : 'bg-[#e9dfcd] text-[#54716d]'}`} data-testid={`button-save-listing-${listing.id}`}><Bookmark size={16} fill={saved ? 'currentColor' : 'none'} /></button><p className="pr-12 text-[13px] leading-5 text-[#617572]">{listing.location} <span className="mx-1 text-[#bdc5bb]">·</span> {listing.distanceKm} km</p><h3 className="mt-2 pr-10 text-lg font-extrabold leading-tight tracking-[-.02em] text-[#183b3e]" data-testid={`text-listing-title-${listing.id}`}>{listing.title}</h3><p className="mt-4 font-display text-3xl text-[#183b3e]" data-testid={`text-listing-price-${listing.id}`}>{currency(listing.price)}</p><div className="mt-4 flex items-center gap-2 border-t border-[#e6dece] pt-3"><Avatar initials={listing.sellerInitials} size="sm" /><span className="text-xs font-bold text-[#496966]">{listing.sellerName}</span>{listing.isVerified && <BadgeCheck size={14} className="text-[#3b8176]" />}<span className="ml-auto flex items-center gap-1 text-xs font-bold text-[#9a7b38]"><Star size={13} fill="currentColor" /> {listing.sellerRating}</span></div></div>
  </Link>;
}

function ListingPage() {
  const { id } = useParams<{ id: string }>();
  const listingId = Number(id);
  const listingQuery = useGetListing(listingId, { query: { queryKey: getGetListingQueryKey(listingId) } });
  const createOrder = useCreateOrder();
  const queryClient = useQueryClient();
  const [showBuy, setShowBuy] = useState(false);
  const [ordered, setOrdered] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const listing = listingQuery.data as ListingLike | undefined;
  if (listingQuery.isLoading) return <DetailSkeleton />;
  if (listingQuery.isError || !listing) return <ErrorState retry={() => listingQuery.refetch()} />;
  const buy = () => {
    if (deliveryAddress.trim().length < 8) return;
    createOrder.mutate({ data: { listingId, deliveryAddress: deliveryAddress.trim() } }, { onSuccess: () => { setOrdered(true); setShowBuy(false); queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetListingQueryKey(listingId) }); } });
  };
  return <div className="mx-auto max-w-5xl">
    <Link href="/" className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-[#57706d]" data-testid="link-back-discover"><ArrowLeft size={16} /> Back to nearby</Link>
    <div className="grid gap-7 md:grid-cols-[1.1fr_.9fr]"><div><ListingImage listing={listing} className="aspect-[4/3] rounded-[28px] sm:aspect-[5/4]" /><div className="mt-5 flex items-center gap-3"><Avatar initials={listing.sellerInitials} /><div><p className="text-sm font-extrabold text-[#183b3e]">{listing.sellerName} {listing.isVerified && <BadgeCheck className="inline text-[#347e73]" size={15} />}</p><p className="mt-0.5 flex items-center gap-1 text-xs text-[#6d817c]"><Star size={12} className="text-[#b98d2f]" fill="currentColor" /> {listing.sellerRating} · {listing.sellerSales} sales</p></div><button className="ml-auto inline-flex items-center gap-2 rounded-full bg-[#e8e0ce] px-4 py-2.5 text-xs font-bold text-[#315955]" data-testid="button-message-seller"><MessageCircle size={15} /> Message seller</button></div></div>
      <div className="flex flex-col"><div className="flex items-center gap-2"><TrustPill><MapPin size={12} /> {listing.distanceKm} km away</TrustPill><TrustPill warm>{listing.category}</TrustPill></div><h1 className="mt-4 font-display text-5xl leading-[.95] tracking-[-.03em] text-[#183b3e] sm:text-6xl" data-testid="text-detail-title">{listing.title}</h1><p className="mt-5 text-sm leading-7 text-[#607473]" data-testid="text-detail-description">{listing.description}</p><div className="mt-7 flex items-end justify-between border-b border-[#dfd5c3] pb-6"><div><p className="font-mono-app text-[10px] uppercase tracking-[.15em] text-[#8b9a91]">Asking price</p><p className="mt-1 font-display text-4xl text-[#183b3e]" data-testid="text-detail-price">{currency(listing.price)}</p></div><p className="text-right text-xs font-bold text-[#7f9088]">{listing.location}<br />listed {shortDate(listing.createdAt)}</p></div>
        <div className="mt-6 rounded-2xl border border-[#cddfd4] bg-[#e8f2eb] p-4"><div className="flex gap-3"><LockKeyhole size={18} className="mt-0.5 shrink-0 text-[#347e73]" /><div><p className="text-sm font-extrabold text-[#183b3e]">Protected doorstep delivery</p><p className="mt-1 text-xs leading-5 text-[#607473]">Payment is held safely while the seller dispatches your item. Confirm once it arrives.</p></div></div></div>
        {ordered ? <div className="mt-5 rounded-2xl border border-[#cddfd4] bg-[#dcefe9] p-5 text-center animate-rise-in"><Check className="mx-auto mb-2 text-[#347e73]" size={26} /><p className="font-extrabold text-[#183b3e]">You’re in. Payment is protected.</p><p className="mt-1 text-xs text-[#607473]">We’ll keep the next steps in your deals.</p><Link href="/orders" className="mt-4 inline-flex items-center gap-2 text-sm font-extrabold text-[#27635f]" data-testid="link-view-order">View my deal <ArrowRight size={15} /></Link></div> : <button onClick={() => setShowBuy(true)} disabled={listing.status !== 'available'} className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#df6c55] px-5 py-4 text-sm font-extrabold text-[#fff9ee] shadow-sm transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:bg-[#b9c3bc]" data-testid="button-buy-protected"><WalletCards size={18} /> {listing.status === 'available' ? 'Buy with protection' : 'No longer available'} <ArrowRight size={17} /></button>}
      </div></div>
    {showBuy && <div className="fixed inset-0 z-50 grid items-end bg-[#183b3e]/45 sm:place-items-center sm:p-5" onClick={() => setShowBuy(false)}><div className="w-full max-w-md rounded-t-[28px] bg-[#f9f4e9] p-6 sm:rounded-[28px]" onClick={e => e.stopPropagation()}><div className="mb-5 flex items-center justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.15em] text-[#df6c55]">One safe step</p><h2 className="mt-1 font-display text-3xl text-[#183b3e]">Where should we deliver?</h2></div><button onClick={() => setShowBuy(false)} className="grid size-9 place-items-center rounded-full bg-[#e8e0ce]" data-testid="button-close-buy"><X size={17} /></button></div><div className="rounded-2xl bg-[#e8f2eb] p-4"><div className="flex justify-between text-sm font-bold text-[#183b3e]"><span>{listing.title}</span><span>{currency(listing.price)}</span></div><div className="mt-3 flex items-start gap-2 text-xs leading-5 text-[#607473]"><LockKeyhole size={14} className="mt-0.5 text-[#347e73]" /> Your payment stays in escrow while the seller dispatches. Release it only after the item arrives as described.</div></div><label className="mt-5 block"><span className="text-xs font-extrabold text-[#315955]">Delivery address</span><textarea required minLength={8} value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} placeholder="Street, suburb, city, postal code" rows={3} className="mt-2 w-full resize-none rounded-xl border border-[#d9cebb] bg-[#f4efdf] px-4 py-3.5 text-sm outline-none focus:border-[#347e73]" data-testid="input-delivery-address" /></label><button onClick={buy} disabled={deliveryAddress.trim().length < 8 || createOrder.isPending} className="mt-5 w-full rounded-2xl bg-[#df6c55] py-4 text-sm font-extrabold text-[#fff9ee] disabled:opacity-60" data-testid="button-confirm-purchase">{createOrder.isPending ? 'Securing your delivery…' : `Confirm protected purchase · ${currency(listing.price)}`}</button><p className="mt-3 text-center text-[11px] text-[#82928a]">No funds are released to the seller yet.</p></div></div>}
  </div>;
}

function DetailSkeleton() { return <div className="grid gap-7 md:grid-cols-[1.1fr_.9fr]"><div className="aspect-[4/3] animate-pulse-soft rounded-[28px] bg-[#e3d9c7]" /><div className="space-y-5 pt-4"><div className="h-4 w-24 animate-pulse-soft rounded bg-[#e3d9c7]" /><div className="h-20 w-3/4 animate-pulse-soft rounded bg-[#e3d9c7]" /><div className="h-24 w-full animate-pulse-soft rounded bg-[#e3d9c7]" /></div></div>; }

function SellPage() {
  const createListing = useCreateListing();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const [form, setForm] = useState({ title: '', description: '', price: '', imageUrl: '', category: 'Home finds', location: 'Cape Town' });
  const [submitted, setSubmitted] = useState(false);
  const update = (key: keyof typeof form, value: string) => setForm(prev => ({ ...prev, [key]: value }));
  const submit = (event: React.FormEvent) => { event.preventDefault(); createListing.mutate({ data: { ...form, price: Number(form.price), imageUrl: form.imageUrl || fallbackImage } }, { onSuccess: (listing) => { setSubmitted(true); queryClient.invalidateQueries({ queryKey: getListListingsQueryKey() }); setTimeout(() => navigate(`/listing/${listing.id}`), 900); } }); };
  if (submitted) return <div className="mx-auto max-w-xl py-16 text-center animate-rise-in"><span className="mx-auto grid size-16 place-items-center rounded-[22px] bg-[#f2c45a] text-[#183b3e]"><Check size={29} /></span><h1 className="mt-6 font-display text-5xl text-[#183b3e]">That’s a good one.</h1><p className="mt-3 text-sm text-[#607473]">Your listing is live. Nearby buyers can now find it.</p></div>;
  return <div className="mx-auto max-w-4xl"><Link href="/" className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-[#57706d]" data-testid="link-back-sell"><ArrowLeft size={16} /> Back to discover</Link><div className="grid gap-8 md:grid-cols-[.75fr_1.25fr]"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-[#df6c55]">Pass it on</p><h1 className="mt-2 font-display text-6xl leading-[.9] tracking-[-.03em] text-[#183b3e]">Sell to<br /><em>someone close.</em></h1><p className="mt-5 max-w-xs text-sm leading-6 text-[#607473]">Good listings are clear, honest, and local. We’ll help the right person find yours.</p><div className="mt-8 hidden space-y-3 sm:block"><div className="flex gap-3"><span className="grid size-8 place-items-center rounded-xl bg-[#dcefe9] text-[#347e73]"><PencilLine size={15} /></span><span className="pt-1 text-xs font-bold text-[#57706d]">Describe it like a human</span></div><div className="flex gap-3"><span className="grid size-8 place-items-center rounded-xl bg-[#fff0c6] text-[#8a691a]"><MapPin size={15} /></span><span className="pt-1 text-xs font-bold text-[#57706d]">Add your dispatch area</span></div></div></div>
      <form onSubmit={submit} className="rounded-[28px] border border-[#e0d6c4] bg-[#f9f4e9] p-5 shadow-[0_18px_50px_hsl(198_35%_17%/.06)] sm:p-7"><div className="space-y-5"><label className="block"><span className="text-xs font-extrabold text-[#315955]">What are you selling?</span><input required minLength={2} value={form.title} onChange={e => update('title', e.target.value)} placeholder="e.g. Mid-century reading chair" className="mt-2 w-full rounded-xl border border-[#d9cebb] bg-[#f4efdf] px-4 py-3.5 text-sm outline-none transition-colors focus:border-[#347e73]" data-testid="input-sell-title" /></label><label className="block"><span className="text-xs font-extrabold text-[#315955]">Tell the story</span><textarea required value={form.description} onChange={e => update('description', e.target.value)} placeholder="Condition, quirks, what you love about it…" rows={4} className="mt-2 w-full resize-none rounded-xl border border-[#d9cebb] bg-[#f4efdf] px-4 py-3.5 text-sm outline-none focus:border-[#347e73]" data-testid="input-sell-description" /></label><div className="grid gap-4 sm:grid-cols-2"><label className="block"><span className="text-xs font-extrabold text-[#315955]">Price</span><div className="mt-2 flex items-center rounded-xl border border-[#d9cebb] bg-[#f4efdf] px-4"><span className="font-display text-xl text-[#7d918b]">R</span><input required type="number" min="1" value={form.price} onChange={e => update('price', e.target.value)} placeholder="850" className="w-full bg-transparent px-2 py-3.5 text-sm outline-none" data-testid="input-sell-price" /></div></label><label className="block"><span className="text-xs font-extrabold text-[#315955]">Category</span><select value={form.category} onChange={e => update('category', e.target.value)} className="mt-2 w-full rounded-xl border border-[#d9cebb] bg-[#f4efdf] px-4 py-3.5 text-sm outline-none" data-testid="select-sell-category">{categories.slice(1).map(item => <option key={item}>{item}</option>)}</select></label></div><label className="block"><span className="text-xs font-extrabold text-[#315955]">Seller / dispatch area</span><div className="mt-2 flex items-center rounded-xl border border-[#d9cebb] bg-[#f4efdf] px-4"><MapPin size={17} className="text-[#df6c55]" /><input required value={form.location} onChange={e => update('location', e.target.value)} placeholder="Cape Town" className="w-full bg-transparent px-3 py-3.5 text-sm outline-none" data-testid="input-sell-location" /></div></label><label className="block"><span className="text-xs font-extrabold text-[#315955]">Photo URL <span className="font-normal text-[#94a39d]">(optional)</span></span><div className="mt-2 flex items-center rounded-xl border border-dashed border-[#c9d7cc] bg-[#edf4ef] px-4"><ImagePlus size={17} className="text-[#347e73]" /><input value={form.imageUrl} onChange={e => update('imageUrl', e.target.value)} placeholder="Paste a photo link" className="w-full bg-transparent px-3 py-3.5 text-sm outline-none" data-testid="input-sell-image" /></div></label></div><button type="submit" disabled={createListing.isPending} className="mt-7 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#df6c55] py-4 text-sm font-extrabold text-[#fff9ee] disabled:opacity-60" data-testid="button-submit-listing">{createListing.isPending ? 'Publishing your listing…' : 'Publish listing'} <ArrowRight size={17} /></button>{createListing.isError && <p className="mt-3 text-center text-xs font-bold text-[#c35c4d]" data-testid="status-sell-error">Couldn’t publish this one. Please try again.</p>}</form></div></div>;
}

function OrdersPage() {
  const ordersQuery = useListOrders({ query: { queryKey: getListOrdersQueryKey() } });
  const confirmOrder = useConfirmOrder();
  const disputeOrder = useDisputeOrder();
  const queryClient = useQueryClient();
  const [disputeId, setDisputeId] = useState<number | null>(null);
  const [reason, setReason] = useState('');
  const orders = (ordersQuery.data || []) as OrderLike[];
  const confirm = (id: number) => confirmOrder.mutate({ id }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() }) });
  const dispute = (id: number) => { if (reason.trim().length < 5) return; disputeOrder.mutate({ id, data: { reason } }, { onSuccess: () => { setDisputeId(null); setReason(''); queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() }); } }); };
  return <div className="mx-auto max-w-3xl space-y-8"><div><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-[#df6c55]">Your trail</p><h1 className="mt-2 font-display text-6xl leading-none tracking-[-.03em] text-[#183b3e]">My deals.</h1><p className="mt-3 text-sm text-[#607473]">Every purchase, with a clear next step.</p></div>{ordersQuery.isLoading ? <div className="space-y-4"><OrderSkeleton /><OrderSkeleton /></div> : ordersQuery.isError ? <ErrorState retry={() => ordersQuery.refetch()} /> : orders.length ? <div className="space-y-4">{orders.map(order => <OrderCard key={order.id} order={order} onConfirm={confirm} onDispute={() => setDisputeId(order.id)} busy={confirmOrder.isPending || disputeOrder.isPending} />)}</div> : <EmptyState title="Your next good deal is out there" detail="When you buy something nearby, its protection journey will live here." action={<Link href="/" className="rounded-full bg-[#df6c55] px-5 py-3 text-sm font-bold text-[#fff9ee]" data-testid="link-orders-discover">Explore nearby</Link>} />}
    {disputeId && <div className="fixed inset-0 z-50 grid items-end bg-[#183b3e]/45 sm:place-items-center sm:p-5"><div className="w-full max-w-md rounded-t-[28px] bg-[#f9f4e9] p-6 sm:rounded-[28px]"><div className="flex items-start justify-between"><div><p className="font-mono-app text-[10px] uppercase tracking-[.15em] text-[#df6c55]">We’ll help</p><h2 className="mt-1 font-display text-3xl text-[#183b3e]">What went wrong?</h2></div><button onClick={() => setDisputeId(null)} className="grid size-9 place-items-center rounded-full bg-[#e8e0ce]" data-testid="button-close-dispute"><X size={17} /></button></div><textarea autoFocus value={reason} onChange={e => setReason(e.target.value)} placeholder="Tell us what happened…" rows={4} className="mt-5 w-full resize-none rounded-xl border border-[#d9cebb] bg-[#f4efdf] px-4 py-3.5 text-sm outline-none focus:border-[#df6c55]" data-testid="input-dispute-reason" /><button onClick={() => dispute(disputeId)} disabled={reason.trim().length < 5 || disputeOrder.isPending} className="mt-4 w-full rounded-2xl bg-[#df6c55] py-4 text-sm font-extrabold text-[#fff9ee] disabled:opacity-40" data-testid="button-submit-dispute">Open protection review</button></div></div>}
  </div>;
}

function OrderCard({ order, onConfirm, onDispute, busy }: { order: OrderLike; onConfirm: (id: number) => void; onDispute: () => void; busy: boolean }) {
  const steps = ['Payment', 'Escrow', 'Dispatch', 'Delivered'];
  const active = order.status === 'payment_pending' ? 0 : order.status === 'in_escrow' ? 1 : order.status === 'delivery_in_transit' ? 2 : 3;
  const canConfirm = order.status === 'delivered' || order.deliveryStatus === 'delivered';
  return <article className="rounded-[24px] border border-[#e0d6c4] bg-[#f9f4e9] p-5 sm:p-6" data-testid={`card-order-${order.id}`}><div className="flex items-start justify-between gap-4"><div><div className="flex flex-wrap items-center gap-2"><TrustPill warm={order.deliveryStatus === 'delivered'}>{order.status === 'in_escrow' && <LockKeyhole size={12} />}{statusLabel[order.status] || order.status}</TrustPill><span className="text-[11px] font-bold text-[#70847d]" data-testid={`status-delivery-${order.id}`}>{deliveryLabel[order.deliveryStatus] || order.deliveryStatus}</span></div><h2 className="mt-3 text-xl font-extrabold tracking-[-.02em] text-[#183b3e]" data-testid={`text-order-title-${order.id}`}>{order.listingTitle}</h2><p className="mt-1 text-xs text-[#71817c]">From {order.sellerName} · {shortDate(order.createdAt)}</p></div><p className="font-display text-2xl text-[#183b3e]" data-testid={`text-order-amount-${order.id}`}>{currency(order.amount)}</p></div><div className="my-6 grid grid-cols-4 gap-1">{steps.map((step, index) => <div key={step}><div className={`h-1.5 rounded-full ${index <= active ? 'bg-[#347e73]' : 'bg-[#dfd5c3]'}`} /><p className={`mt-2 text-[10px] font-bold ${index <= active ? 'text-[#347e73]' : 'text-[#9aa69f]'}`}>{step}</p></div>)}</div><div className="flex items-start gap-2 rounded-xl bg-[#edf4ef] p-3 text-xs text-[#607473]"><MapPin size={14} className="mt-0.5 shrink-0 text-[#df6c55]" /><span><strong className="text-[#315955]">Delivery address</strong><span className="block mt-1" data-testid={`text-delivery-address-${order.id}`}>{order.deliveryAddress}</span>{order.status === 'in_escrow' && <span className="block mt-1">Protection stays active while dispatch is in progress.</span>}{order.status === 'delivery_in_transit' && <span className="block mt-1">Your parcel is on its way.</span>}</span></div>{canConfirm && <div className="mt-4 flex gap-2"><button onClick={() => onConfirm(order.id)} disabled={busy} className="flex-1 rounded-xl bg-[#347e73] py-3 text-xs font-extrabold text-[#f9f4e9] disabled:opacity-50" data-testid={`button-confirm-order-${order.id}`}><Check className="mr-1 inline" size={14} /> Item arrived as described</button><button onClick={onDispute} className="rounded-xl border border-[#dfd5c3] px-4 py-3 text-xs font-bold text-[#9a5d50]" data-testid={`button-dispute-order-${order.id}`}>Problem?</button></div>}{order.status === 'completed' && <p className="mt-4 flex items-center gap-2 text-xs font-bold text-[#347e73]"><PackageCheck size={16} /> Funds released after delivery confirmation.</p>}</article>;
}
function OrderSkeleton() { return <div className="rounded-[24px] border border-[#e0d6c4] bg-[#f9f4e9] p-6"><div className="h-5 w-1/2 animate-pulse-soft rounded bg-[#e3d9c7]" /><div className="mt-6 h-2 w-full animate-pulse-soft rounded bg-[#e3d9c7]" /><div className="mt-5 h-14 w-full animate-pulse-soft rounded-xl bg-[#e3d9c7]" /></div>; }

function ProfilePage() {
  const profileQuery = useGetProfile({ query: { queryKey: getGetProfileQueryKey() } });
  const profile = profileQuery.data;
  if (profileQuery.isLoading) return <div className="mx-auto max-w-2xl space-y-5"><div className="h-48 animate-pulse-soft rounded-[28px] bg-[#e3d9c7]" /><div className="h-32 animate-pulse-soft rounded-[28px] bg-[#e3d9c7]" /></div>;
  if (profileQuery.isError || !profile) return <ErrorState retry={() => profileQuery.refetch()} />;
  return <div className="mx-auto max-w-3xl space-y-6"><div className="relative overflow-hidden rounded-[28px] bg-[#183b3e] px-6 py-8 text-[#f9f4e9] sm:px-9"><div className="absolute -right-10 -top-16 size-52 rounded-full border-[18px] border-[#2d6862]/50" /><div className="relative flex items-center gap-4"><Avatar initials={profile.initials} size="lg" /><div><div className="flex items-center gap-2"><h1 className="text-2xl font-extrabold" data-testid="text-profile-name">{profile.name}</h1>{profile.isVerified && <BadgeCheck className="text-[#f2c45a]" size={18} />}</div><p className="mt-1 flex items-center gap-1.5 text-sm text-[#b7d0c4]"><MapPin size={14} /> {profile.location}</p></div></div><div className="relative mt-8 grid grid-cols-3 gap-4 border-t border-[#46716a] pt-5"><div><p className="font-display text-3xl text-[#f2c45a]">{profile.rating}</p><p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#b7d0c4]">rating</p></div><div><p className="font-display text-3xl text-[#f2c45a]">{profile.completedSales}</p><p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#b7d0c4]">sales done</p></div><div><p className="font-display text-3xl text-[#f2c45a]">{profile.protectedPurchases}</p><p className="text-[10px] font-bold uppercase tracking-[.1em] text-[#b7d0c4]">protected buys</p></div></div></div><div className="grid gap-4 sm:grid-cols-2"><div className="rounded-[24px] border border-[#e0d6c4] bg-[#f9f4e9] p-5"><ShieldCheck className="text-[#347e73]" size={23} /><h2 className="mt-4 text-lg font-extrabold text-[#183b3e]">Trust signals</h2><p className="mt-1 text-sm leading-6 text-[#607473]">You’ve built a profile people can feel good about buying from.</p><div className="mt-5 space-y-3 text-xs font-bold text-[#57706d]"><div className="flex justify-between border-b border-[#e6dece] pb-3"><span>Identity checked</span><Check size={15} className="text-[#347e73]" /></div><div className="flex justify-between border-b border-[#e6dece] pb-3"><span>Community rating</span><span className="text-[#9a7b38]">Excellent</span></div><div className="flex justify-between"><span>Member since</span><span>{shortDate(profile.joinedAt)}</span></div></div></div><div className="rounded-[24px] border border-[#e0d6c4] bg-[#fff0c6] p-5"><Sparkles className="text-[#9a741e]" size={23} /><h2 className="mt-4 text-lg font-extrabold text-[#183b3e]">Keep it local</h2><p className="mt-1 text-sm leading-6 text-[#6d6445]">The best TrustLink deals stay close enough for simple, reliable delivery.</p><Link href="/safety" className="mt-5 inline-flex items-center gap-2 text-xs font-extrabold text-[#805f11]" data-testid="link-profile-safety">Read the safety guide <ArrowRight size={14} /></Link></div></div></div>;
}

function SafetyPage() {
  const blocks = [{ icon: WalletCards, title: 'Payment stays protected', text: 'When you buy, your payment is held in escrow. The seller only gets paid when you confirm the delivered item matches the listing.' }, { icon: MapPin, title: 'Delivery stays visible', text: 'Your order shows the delivery address and dispatch status, from pending to in transit to delivered.' }, { icon: FileCheck2, title: 'You stay in control', text: 'Check your parcel when it arrives. Confirm when you’re happy, or open a review if something is not right.' }];
  return <div className="mx-auto max-w-4xl"><div className="relative overflow-hidden rounded-[30px] bg-[#f2c45a] px-6 py-10 sm:px-12 sm:py-14"><div className="absolute -right-14 -top-20 size-60 rounded-full border-[22px] border-[#e3a94b]/70" /><div className="relative max-w-xl"><p className="font-mono-app text-[10px] uppercase tracking-[.18em] text-[#6d551a]">The TrustLink promise</p><h1 className="mt-3 font-display text-[clamp(3.3rem,8vw,6rem)] leading-[.88] tracking-[-.04em] text-[#183b3e]">Safer shopping<br /><em>to your doorstep.</em></h1><p className="mt-6 max-w-md text-[15px] leading-7 text-[#536052]">Because a good deal should feel good before, during, and after delivery.</p></div></div><div className="mt-8 grid gap-4 md:grid-cols-3">{blocks.map(({ icon: Icon, title, text }, index) => <div className="animate-rise-in rounded-[24px] border border-[#e0d6c4] bg-[#f9f4e9] p-5" key={title} style={{ animationDelay: `${index * 80}ms` }}><span className="grid size-11 place-items-center rounded-2xl bg-[#dcefe9] text-[#347e73]"><Icon size={21} /></span><h2 className="mt-5 text-lg font-extrabold text-[#183b3e]">{title}</h2><p className="mt-2 text-sm leading-6 text-[#607473]">{text}</p></div>)}</div><div className="mt-8 rounded-[26px] border border-[#cddfd4] bg-[#e8f2eb] p-6 sm:p-8"><div className="flex gap-4"><span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-[#347e73] text-[#f9f4e9]"><ShieldCheck size={23} /></span><div><h2 className="text-lg font-extrabold text-[#183b3e]">Our simple four-step flow</h2><div className="mt-5 space-y-4">{['Choose a listing and start a protected purchase.', 'Add your delivery address and let the seller dispatch it.', 'Track the order until it arrives at your doorstep.', 'Check the item, then confirm to release payment.'].map((step, i) => <div className="flex gap-3 text-sm text-[#57706d]" key={step}><span className="grid size-6 shrink-0 place-items-center rounded-full bg-[#f2c45a] text-xs font-extrabold text-[#183b3e]">{i + 1}</span><span>{step}</span></div>)}</div></div></div></div><div className="mt-8 flex flex-col items-center justify-between gap-4 rounded-[24px] border border-[#e0d6c4] bg-[#f9f4e9] p-6 text-center sm:flex-row sm:text-left"><div><p className="text-sm font-extrabold text-[#183b3e]">Ready to find something nearby?</p><p className="mt-1 text-xs text-[#7d8c85]">Good people are already dispatching.</p></div><Link href="/" className="inline-flex items-center gap-2 rounded-full bg-[#df6c55] px-5 py-3 text-sm font-extrabold text-[#fff9ee]" data-testid="link-safety-discover">Explore listings <ArrowRight size={16} /></Link></div></div>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><AppShell><Switch><Route path="/" component={Home} /><Route path="/listing/:id" component={ListingPage} /><Route path="/sell" component={SellPage} /><Route path="/orders" component={OrdersPage} /><Route path="/profile" component={ProfilePage} /><Route path="/safety" component={SafetyPage} /><Route component={NotFound} /></Switch></AppShell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><Router /><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;