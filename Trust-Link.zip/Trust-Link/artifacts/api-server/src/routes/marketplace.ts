import { and, desc, eq, ilike } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db, listingsTable, ordersTable } from "@workspace/db";
import {
  ConfirmOrderParams,
  ConfirmOrderResponse,
  CreateListingBody,
  CreateListingResponse,
  CreateOrderBody,
  CreateOrderResponse,
  DisputeOrderBody,
  DisputeOrderParams,
  DisputeOrderResponse,
  GetDashboardResponse,
  GetListingParams,
  GetListingResponse,
  GetProfileResponse,
  ListListingsQueryParams,
  ListListingsResponse,
  ListOrdersResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const profile = {
  id: 1,
  name: "Lerato Mokoena",
  initials: "LM",
  location: "Soweto, Gauteng",
  rating: 4.9,
  completedSales: 12,
  protectedPurchases: 4,
  joinedAt: "March 2025",
  isVerified: true,
};

const seedListings = [
  {
    title: "Sony Alpha a6400",
    description: "Lightly used mirrorless camera with 16–50mm kit lens. Perfect for content, family moments, and weekend shoots.",
    price: "8200",
    imageUrl: "/listing-camera.jpg",
    category: "Electronics",
    location: "Hatfield, Pretoria",
    distanceKm: "2.4",
    sellerName: "Thabo Nkosi",
    sellerInitials: "TN",
    sellerRating: "4.9",
    sellerSales: 28,
    isVerified: true,
    status: "reserved",
  },
  {
    title: "Sage lounge chair",
    description: "A calm corner piece in excellent condition. No stains, no tears, and ready for a new home.",
    price: "1450",
    imageUrl: "/listing-chair.jpg",
    category: "Home",
    location: "Maboneng, Johannesburg",
    distanceKm: "4.1",
    sellerName: "Nandi Dlamini",
    sellerInitials: "ND",
    sellerRating: "4.8",
    sellerSales: 16,
    isVerified: true,
    status: "available",
  },
  {
    title: "Everyday sneakers · size 7",
    description: "Fresh white-and-green trainers worn twice. Clean, comfortable, and ready to go.",
    price: "650",
    imageUrl: "/listing-sneakers.jpg",
    category: "Fashion",
    location: "Rosebank, Johannesburg",
    distanceKm: "5.7",
    sellerName: "Kea Molefe",
    sellerInitials: "KM",
    sellerRating: "5.0",
    sellerSales: 9,
    isVerified: false,
    status: "available",
  },
];

let seedPromise: Promise<void> | undefined;

function toListing(row: typeof listingsTable.$inferSelect) {
  return {
    ...row,
    price: Number(row.price),
    distanceKm: Number(row.distanceKm),
    sellerRating: Number(row.sellerRating),
    createdAt: row.createdAt.toISOString(),
  };
}

function toOrder(row: typeof ordersTable.$inferSelect) {
  return {
    ...row,
    amount: Number(row.amount),
    protectionEndsAt: row.protectionEndsAt.toISOString(),
    createdAt: row.createdAt.toISOString(),
  };
}

async function ensureSeedData(): Promise<void> {
  if (seedPromise) return seedPromise;

  seedPromise = (async () => {
    const existingListings = await db.select().from(listingsTable).orderBy(listingsTable.id);
    const seenTitles = new Set<string>();
    const duplicateIds: number[] = [];
    for (const listing of existingListings) {
      if (seenTitles.has(listing.title)) {
        duplicateIds.push(listing.id);
      } else {
        seenTitles.add(listing.title);
      }
    }

    for (const duplicateId of duplicateIds) {
      await db.delete(ordersTable).where(eq(ordersTable.listingId, duplicateId));
      await db.delete(listingsTable).where(eq(listingsTable.id, duplicateId));
    }

    if (existingListings.length > 0) return;

    const inserted = await db.insert(listingsTable).values(seedListings).returning();
    const reservedListing = inserted.find((listing) => listing.status === "reserved");
    if (!reservedListing) return;

    const protectionEndsAt = new Date(Date.now() + 34 * 60 * 60 * 1000);
    await db.insert(ordersTable).values({
      listingId: reservedListing.id,
      listingTitle: reservedListing.title,
      amount: reservedListing.price,
      status: "delivery_in_transit",
      deliveryAddress: "12 Long Street, Cape Town",
      deliveryStatus: "in_transit",
      sellerName: reservedListing.sellerName,
      protectionEndsAt,
    });
  })();

  try {
    await seedPromise;
  } catch (error) {
    seedPromise = undefined;
    throw error;
  }
}

router.get("/listings", async (req, res): Promise<void> => {
  const parsed = ListListingsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await ensureSeedData();
  const { search, category, location, limit } = parsed.data;
  const filters = [];
  if (search) filters.push(ilike(listingsTable.title, `%${search}%`));
  if (category && category !== "All") filters.push(eq(listingsTable.category, category));
  if (location && location !== "Near me") filters.push(ilike(listingsTable.location, `%${location}%`));

  const rows = await db
    .select()
    .from(listingsTable)
    .where(filters.length > 0 ? and(...filters) : undefined)
    .orderBy(desc(listingsTable.createdAt))
    .limit(limit);

  res.json(ListListingsResponse.parse(rows.map(toListing)));
});

router.post("/listings", async (req, res): Promise<void> => {
  const parsed = CreateListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [listing] = await db.insert(listingsTable).values({
    title: parsed.data.title,
    description: parsed.data.description,
    price: String(parsed.data.price),
    imageUrl: parsed.data.imageUrl,
    category: parsed.data.category,
    location: parsed.data.location,
    distanceKm: "0.8",
    sellerName: profile.name,
    sellerInitials: profile.initials,
    sellerRating: String(profile.rating),
    sellerSales: profile.completedSales,
    isVerified: profile.isVerified,
    status: "available",
  }).returning();

  res.status(201).json(CreateListingResponse.parse(toListing(listing)));
});

router.get("/listings/:id", async (req, res): Promise<void> => {
  const params = GetListingParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await ensureSeedData();
  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, params.data.id));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  res.json(GetListingResponse.parse(toListing(listing)));
});

router.get("/orders", async (_req, res): Promise<void> => {
  await ensureSeedData();
  const rows = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt));
  res.json(ListOrdersResponse.parse(rows.map(toOrder)));
});

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await ensureSeedData();
  const [listing] = await db.select().from(listingsTable).where(eq(listingsTable.id, parsed.data.listingId));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }
  if (listing.status !== "available") {
    res.status(400).json({ error: "This listing is no longer available" });
    return;
  }

  const [order] = await db.insert(ordersTable).values({
    listingId: listing.id,
    listingTitle: listing.title,
    amount: listing.price,
    status: "in_escrow",
    deliveryAddress: parsed.data.deliveryAddress,
    deliveryStatus: "pending",
    sellerName: listing.sellerName,
    protectionEndsAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
  }).returning();
  await db.update(listingsTable).set({ status: "reserved" }).where(eq(listingsTable.id, listing.id));

  res.status(201).json(CreateOrderResponse.parse(toOrder(order)));
});

router.post("/orders/:id/confirm", async (req, res): Promise<void> => {
  const params = ConfirmOrderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [order] = await db.update(ordersTable)
    .set({ status: "completed" })
    .where(eq(ordersTable.id, params.data.id))
    .returning();
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  await db.update(listingsTable).set({ status: "sold" }).where(eq(listingsTable.id, order.listingId));
  res.json(ConfirmOrderResponse.parse(toOrder(order)));
});

router.post("/orders/:id/dispute", async (req, res): Promise<void> => {
  const params = DisputeOrderParams.safeParse(req.params);
  const parsed = DisputeOrderBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [order] = await db.update(ordersTable)
    .set({ status: "disputed", disputeReason: parsed.data.reason })
    .where(eq(ordersTable.id, params.data.id))
    .returning();
  if (!order) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  res.json(DisputeOrderResponse.parse(toOrder(order)));
});

router.get("/profile", (_req, res): void => {
  res.json(GetProfileResponse.parse(profile));
});

router.get("/dashboard", async (_req, res): Promise<void> => {
  await ensureSeedData();
  const listings = await db.select().from(listingsTable);
  const [activeOrder] = await db.select().from(ordersTable)
    .where(eq(ordersTable.deliveryStatus, "in_transit"))
    .orderBy(desc(ordersTable.createdAt))
    .limit(1);
  const averageDistanceKm = listings.length
    ? listings.reduce((sum, listing) => sum + Number(listing.distanceKm), 0) / listings.length
    : 0;

  res.json(GetDashboardResponse.parse({
    nearbyCount: listings.filter((listing) => listing.status === "available").length,
    safeDealsCount: listings.length + 18,
    averageDistanceKm: Number(averageDistanceKm.toFixed(1)),
    trustScore: 96,
    featuredListings: listings.filter((listing) => listing.status === "available").slice(0, 3).map(toListing),
    activeOrder: activeOrder ? toOrder(activeOrder) : null,
  }));
});

export default router;